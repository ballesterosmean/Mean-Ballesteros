package com.example.lab_act_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
