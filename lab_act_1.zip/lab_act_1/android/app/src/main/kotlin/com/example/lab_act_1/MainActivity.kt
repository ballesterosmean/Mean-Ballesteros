package com.example.lab_act_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
