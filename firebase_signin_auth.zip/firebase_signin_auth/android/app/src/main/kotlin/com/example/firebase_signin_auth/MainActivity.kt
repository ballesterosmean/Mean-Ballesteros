package com.example.firebase_signin_auth

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
