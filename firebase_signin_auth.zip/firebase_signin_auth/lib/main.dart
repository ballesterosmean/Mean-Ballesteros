import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:firebase_signin_auth/screen/signin_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
// This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter and Firebase Authentication',
      theme: ThemeData(
      // This is the theme of your application.
      //
      // Try running your application with &quot;flutter run&quot;. You&#39;ll see the
      // application has a blue toolbar. Then, without quitting the app, try
      // changing the primarySwatch below to Colors.green and then invoke
      // &quot;hot reload&quot; (press &quot;r&quot; in the console where you ran "flutter run
      // or simply save your changes to &quot;hot reload&quot; in a Flutter IDE).
      // Notice that the counter didn&#39;t reset back to zero; the application
      // is not restarted.
      primarySwatch: Colors.blue,
      ),
      home: const SignInScreen(),
    );
  }
}
