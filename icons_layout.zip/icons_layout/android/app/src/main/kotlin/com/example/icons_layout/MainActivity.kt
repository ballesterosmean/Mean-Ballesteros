package com.example.icons_layout

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
