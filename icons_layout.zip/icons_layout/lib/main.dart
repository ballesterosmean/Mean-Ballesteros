import 'package:flutter/material.dart';


void main() {
  runApp(
      MyApp()
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Colors.white,

        appBar: PreferredSize(


          preferredSize: Size.fromHeight(60.0),

          child: AppBar(

            backgroundColor: Colors.white,
            title: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Image.asset('images/ytlogo.jpg', height: 99.0, width: 150.0),
                Icon(
                  Icons.video_call,
                  color: Colors.black,

                ),
                Icon(
                  Icons.search,
                  color: Colors.black,
                ),
                Icon(
                  Icons.account_circle_rounded,
                  color: Colors.black,
                ),



              ],

            ),


          ),


        ),
        bottomNavigationBar: BottomNavigationBar(
          items: [
            BottomNavigationBarItem(icon: Icon(Icons.home),
                label: 'Home'),
            BottomNavigationBarItem(icon: Icon(Icons.subscriptions),
                label: 'Subscription'),
            BottomNavigationBarItem(icon: Icon(Icons.video_library),
                label: 'Library'),
          ],
        ),



        body: Center(
          child:Image(
            image:AssetImage('images/home.jpg'),

          ),

        ),
      ),

    );
  }


}
